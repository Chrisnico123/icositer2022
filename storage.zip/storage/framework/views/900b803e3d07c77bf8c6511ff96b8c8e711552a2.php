<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registrasi Lomba</title>
    <link rel="stylesheet" href="/Lomba/style.css">
    <link rel="stylesheet" href="/Lomba/register.css">
    <link rel="stylesheet" type="text.css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.min.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <?php echo $__env->yieldContent('page1'); ?>
        <?php echo $__env->yieldContent('page2'); ?>
        <?php echo $__env->yieldContent('page3'); ?>
        <?php echo $__env->yieldContent('page4'); ?>
        <?php echo $__env->yieldContent('page5'); ?>
    </div>
    <section>
        <img src="<?php echo e(asset('assets')); ?>/images/clouds.svg" id="clouds">
        <img src="<?php echo e(asset('assets')); ?>/images/clouds.svg" id="clouds2">
        <img src="<?php echo e(asset('assets')); ?>/images/bigcloud.svg" id="bigcloud">
        <img src="<?php echo e(asset('assets')); ?>/images/mountain.svg" id="mountain">
        <img src="<?php echo e(asset('assets')); ?>/images/airballoon.svg" id="airballoon">
        <img src="<?php echo e(asset('assets')); ?>/images/pole.svg" id="pole">
        <img src="<?php echo e(asset('assets')); ?>/images/prop.svg" id="prop">
        <img src="<?php echo e(asset('assets')); ?>/images/prop2.svg" id="prop2">
        <img src="<?php echo e(asset('assets')); ?>/images/ground.svg" id="ground">
    </section>
</body>

</html>
<?php /**PATH C:\Users\ASUS\Documents\Website\icositer2022\resources\views/TemplateLomba/lomba1.blade.php ENDPATH**/ ?>