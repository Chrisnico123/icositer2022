
<?php $__env->startSection('page2'); ?>
<form class="row g-3" method="POST" action=<?php echo e(route('lomba3s_page2')); ?> enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
    <div class="nav">
        <div class="name">
            <h1>PROTOTYPE</h1>
        </div>
        <div class="close">
            <a href='/lomba3s/page1'><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
              </svg></a>
        </div>
    </div>
    <div class="col-12">
      <label for="inputEmail4" class="form-label">Scan Ktm (Kartu Tanda Mahasiswa) Semua Peserta Format : NamaTim_KTM.pdf</label>
      <input type="file" class="form-control" id="inputEmail4" placeholder="" name="ktm" value="<?php echo e($lomba3s->ktm ?? ''); ?>">
        <?php $__errorArgs = ['ktm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
      <label for="inputAddress" class="form-label">Upload Sketsa Karya Format : (NamaTim_Subtema_LaporanTahapAwal),pdf </label>
      <input type="file" class="form-control" id="inputAddress" placeholder="" name="sketsa" value="<?php echo e($lomba3s->sketsa ?? ''); ?>">
        <?php $__errorArgs = ['sketsa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-12">
      <label for="inputAddress2" class="form-label">Sub Tema yang dipilih </label>
      <input type="text" class="form-control" id="inputAddress2" placeholder="" name="sub_tema" value="<?php echo e($lomba3s->sub_tema ?? ''); ?>">
        <?php $__errorArgs = ['sub_tema'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-12">
      <label for="inputCity" class="form-label">Judul Karya Prototype of Scientific Innovation</label>
      <input type="text" class="form-control" id="inputCity" name="judul_karya" value="<?php echo e($lomba3s->judul_karya ?? ''); ?>">
        <?php $__errorArgs = ['judul_karya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Next</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('TemplateLomba/lomba1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Website\icositer2022\resources\views/Lomba/Lomba3/page2.blade.php ENDPATH**/ ?>