
<?php $__env->startSection('page3'); ?>
<form class="row g-3" method="POST" action=<?php echo e(route('lomba3s_page3')); ?> enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
    <div class="nav">
        <div class="name">
            <h1>PROTOTYPE</h1>
        </div>
        <div class="close">
            <a href="/lomba3s/page2"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
              </svg></a>
        </div>
    </div>
    <div class="col-12">
      <label for="inputEmail4" class="form-label">Bukti follow IG icos Seluruh anggota tim (Dijadikan Satu) Format : NamaTim_BuktiFollowIG.pdf</label>
      <input type="file" class="form-control" id="inputEmail4" name = "follow_ig" value = "<?php echo e($lomba3s->follow_ig ?? ''); ?>">
      <?php $__errorArgs = ['follow_ig'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class = "text-danger"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
      <label for="inputEmail4" class="form-label">Bukti Upload Twibon Seluruh anggota (Dijadikan Satu) Format : NamaTim_BuktiUPTwibon.pdf</label>
      <input type="file" class="form-control" id="inputPassword4" name = "upload_twibbon" value = "<?php echo e($lomba3s->upload_twibbon ?? ''); ?>">
      <?php $__errorArgs = ['upload_twibbon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class = "text-danger"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
      <label for="inputAddress" class="form-label">Upload Scan Surat Pernyataan Orisinalitas Karya Format : NamaTim_SuratOrisinalitasKarya_Subtema.pdf </label>
      <input type="file" class="form-control" id="inputAddress" name = "surat_pernyataan" value = "<?php echo e($lomba3s->surat_pernyataan ?? ''); ?>">
      <?php $__errorArgs = ['surat_pernyataan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class = "text-danger"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
      <label for="inputAddress" class="form-label">Upload Scan Seluruh Lampiran Data Diri Peserta hingga Dosen Pendamping (Dijadikan Satu) Format : NamaTim_LampiranDataDiri.pdf </label>
      <input type="file" class="form-control" id="inputAddress2" name = "lampiran" value = "<?php echo e($lomba3s->lampiran ?? ''); ?>">
      <?php $__errorArgs = ['lampiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class = "text-danger"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-12">
      <label for="inputState" class="form-label">Upload Bukti Pembayaran Format : pdf</label>
      <input type="file" class="form-control <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputState" name="payment"
          value="<?php echo e(old('payment', $lomba3s->payment ?? '')); ?>">
      <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-12">
      <label for="upload_abstrak" class="form-label">Upload Abstrak : pdf</label>
      <input type="file" class="form-control <?php $__errorArgs = ['upload_abstrak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="upload_abstrak" name="upload_abstrak"
          value="<?php echo e(old('upload_abstrak', $lomba3s->upload_abstrak ?? '')); ?>">
      <?php $__errorArgs = ['upload_abstak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('TemplateLomba/lomba1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Website\icositer2022\resources\views/Lomba/Lomba3/page3.blade.php ENDPATH**/ ?>